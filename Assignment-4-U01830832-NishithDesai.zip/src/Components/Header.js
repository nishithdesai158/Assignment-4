import React from 'react'

function Header() {
    return (
        <header>
            <h1>
                Blogs By Nishith Desai
            </h1>
        </header>
    )
}

export default Header
