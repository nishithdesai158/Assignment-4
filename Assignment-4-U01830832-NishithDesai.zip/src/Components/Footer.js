import React from 'react'

function Footer() {
    return (
        <footer>
            <h1>Copyright &copy; 2021</h1>
        </footer>
    )
}

export default Footer
